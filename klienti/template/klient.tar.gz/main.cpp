#include <iostream>

using namespace std;

int main() {
    while (true) {
	cout << "cd " << "LEFT" << endl;
	cout << "cd " << "RIGHT" << endl;
    }
}
