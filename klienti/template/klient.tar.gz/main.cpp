#include <iostream>
#include <string>

using namespace std;

int main() {
    /*
    int a = 0;
    cout << 5/a;
    */
    while (true) {
        /*
        string str;
        cin >> str;
        */
        cout << "cd " << "LEFT" << endl;
        cout << "cd " << "RIGHT" << endl;
    }
}
