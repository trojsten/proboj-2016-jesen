#include <iostream>

using namespace std;

int main() {
    while (true) { string s; cin >> s; }
}
